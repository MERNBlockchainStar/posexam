from opytimizer.optimizers.swarm import SSA

# Creates a SSA optimizer
o = SSA()
