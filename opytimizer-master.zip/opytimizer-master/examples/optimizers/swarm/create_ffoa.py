from opytimizer.optimizers.swarm import FFOA

# Creates a FFOA optimizer
o = FFOA()
