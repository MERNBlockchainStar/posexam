from opytimizer.optimizers.swarm import SOS

# Creates an SOS optimizer
o = SOS()
