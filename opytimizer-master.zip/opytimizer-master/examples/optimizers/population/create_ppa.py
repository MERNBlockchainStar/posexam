from opytimizer.optimizers.population import PPA

# Creates a PPA optimizer
o = PPA()
