from opytimizer.optimizers.population import PVS

# Creates a PVS optimizer
o = PVS()
