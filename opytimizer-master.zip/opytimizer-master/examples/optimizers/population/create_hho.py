from opytimizer.optimizers.population import HHO

# Creates an HHO optimizer
o = HHO()
