from opytimizer.optimizers.population import GWO

# Creates a GWO optimizer
o = GWO()
