from opytimizer.optimizers.population import AEO

# Creates an AEO optimizer
o = AEO()
