from opytimizer.optimizers.science import BH

# Creates a BH optimizer
o = BH()
