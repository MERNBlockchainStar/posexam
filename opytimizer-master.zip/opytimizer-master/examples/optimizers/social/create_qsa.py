from opytimizer.optimizers.social import QSA

# Creates an QSA optimizer
o = QSA()
