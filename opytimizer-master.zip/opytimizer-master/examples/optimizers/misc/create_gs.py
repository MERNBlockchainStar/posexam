from opytimizer.optimizers.misc import GS

# Creates a grid-search optimizer
o = GS()
