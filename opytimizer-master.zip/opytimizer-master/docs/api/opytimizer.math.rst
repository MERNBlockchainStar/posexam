opytimizer.math
=========================

Just because we are computing stuff does not means that we do not need math. Math is the mathematical package containing low-level math implementations. From random numbers to distribution generation, you can find your needs on this module.

.. toctree::
    opytimizer.math.distribution
    opytimizer.math.general
    opytimizer.math.hyper
    opytimizer.math.random

.. automodule:: opytimizer.math
   :members:
   :show-inheritance: