opytimizer.optimizers.swarm.js
===============================

.. automodule:: opytimizer.optimizers.swarm.js
    :members:
    :private-members:
    :special-members: