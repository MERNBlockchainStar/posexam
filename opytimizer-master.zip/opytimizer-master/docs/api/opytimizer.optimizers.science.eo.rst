opytimizer.optimizers.science.eo
=================================

.. automodule:: opytimizer.optimizers.science.eo
    :members:
    :private-members:
    :special-members: