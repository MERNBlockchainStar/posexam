opytimizer.optimizers.swarm.stoa
=================================

.. automodule:: opytimizer.optimizers.swarm.stoa
    :members:
    :private-members:
    :special-members: