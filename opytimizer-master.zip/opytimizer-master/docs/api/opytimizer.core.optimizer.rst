opytimizer.core.optimizer
==========================

.. automodule:: opytimizer.core.optimizer
    :members:
    :private-members:
    :special-members: