opytimizer.optimizers.boolean
===================================

.. toctree::
    opytimizer.optimizers.boolean.bmrfo
    opytimizer.optimizers.boolean.bpso
    opytimizer.optimizers.boolean.umda

.. automodule:: opytimizer.optimizers.boolean
   :members:
   :show-inheritance: