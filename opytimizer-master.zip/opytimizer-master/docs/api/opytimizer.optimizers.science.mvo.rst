opytimizer.optimizers.science.mvo
==================================

.. automodule:: opytimizer.optimizers.science.mvo
    :members:
    :private-members:
    :special-members: