opytimizer.utils.constant
==========================

.. automodule:: opytimizer.utils.constant
    :members:
    :private-members:
    :special-members: