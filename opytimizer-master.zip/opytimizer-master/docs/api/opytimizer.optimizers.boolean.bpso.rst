opytimizer.optimizers.boolean.bpso
===================================

.. automodule:: opytimizer.optimizers.boolean.bpso
    :members:
    :private-members:
    :special-members: