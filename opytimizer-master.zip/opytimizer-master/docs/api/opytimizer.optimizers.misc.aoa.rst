opytimizer.optimizers.misc.aoa
===============================

.. automodule:: opytimizer.optimizers.misc.aoa
    :members:
    :private-members:
    :special-members: