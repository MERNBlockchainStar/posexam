opytimizer.spaces.boolean
==========================

.. automodule:: opytimizer.spaces.boolean
    :members:
    :private-members:
    :special-members: