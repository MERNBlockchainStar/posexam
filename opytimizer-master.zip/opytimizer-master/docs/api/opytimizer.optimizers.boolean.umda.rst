opytimizer.optimizers.boolean.umda
===================================

.. automodule:: opytimizer.optimizers.boolean.umda
    :members:
    :private-members:
    :special-members: