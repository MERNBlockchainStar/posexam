opytimizer.math.general
==========================

.. automodule:: opytimizer.math.general
    :members:
    :private-members:
    :special-members: