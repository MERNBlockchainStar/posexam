opytimizer.functions.weighted
==============================

.. automodule:: opytimizer.functions.weighted
    :members:
    :private-members:
    :special-members: