opytimizer.optimizers.social.isa
=================================

.. automodule:: opytimizer.optimizers.social.isa
    :members:
    :private-members:
    :special-members: