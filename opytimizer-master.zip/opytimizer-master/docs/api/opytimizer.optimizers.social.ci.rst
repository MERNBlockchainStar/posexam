opytimizer.optimizers.social.ci
================================

.. automodule:: opytimizer.optimizers.social.ci
    :members:
    :private-members:
    :special-members: