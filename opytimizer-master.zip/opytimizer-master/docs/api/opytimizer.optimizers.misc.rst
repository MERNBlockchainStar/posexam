opytimizer.optimizers.misc
===========================

.. toctree::
    opytimizer.optimizers.misc.aoa
    opytimizer.optimizers.misc.cem
    opytimizer.optimizers.misc.doa
    opytimizer.optimizers.misc.gs
    opytimizer.optimizers.misc.hc

.. automodule:: opytimizer.optimizers.misc
   :members:
   :show-inheritance: