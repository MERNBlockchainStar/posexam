opytimizer.optimizers.swarm.boa
================================

.. automodule:: opytimizer.optimizers.swarm.boa
    :members:
    :private-members:
    :special-members: