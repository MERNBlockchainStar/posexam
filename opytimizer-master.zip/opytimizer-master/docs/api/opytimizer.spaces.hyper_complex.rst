opytimizer.spaces.hyper_complex
================================

.. automodule:: opytimizer.spaces.hyper_complex
    :members:
    :private-members:
    :special-members: