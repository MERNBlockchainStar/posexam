opytimizer.functions.constrained
=================================

.. automodule:: opytimizer.functions.constrained
    :members:
    :private-members:
    :special-members: