opytimizer.math.distribution
==============================

.. automodule:: opytimizer.math.distribution
    :members:
    :private-members:
    :special-members: