opytimizer.optimizers.swarm.sos
================================

.. automodule:: opytimizer.optimizers.swarm.sos
    :members:
    :private-members:
    :special-members: