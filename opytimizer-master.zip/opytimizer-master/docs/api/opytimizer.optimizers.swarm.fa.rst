opytimizer.optimizers.swarm.fa
===============================

.. automodule:: opytimizer.optimizers.swarm.fa
    :members:
    :private-members:
    :special-members: