opytimizer.optimizers.social
=============================

.. toctree::
    opytimizer.optimizers.social.bso
    opytimizer.optimizers.social.ci
    opytimizer.optimizers.social.isa
    opytimizer.optimizers.social.mvpa
    opytimizer.optimizers.social.qsa
    opytimizer.optimizers.social.ssd

.. automodule:: opytimizer.optimizers.social
   :members:
   :show-inheritance: