opytimizer.optimizers.misc.doa
===============================

.. automodule:: opytimizer.optimizers.misc.doa
    :members:
    :private-members:
    :special-members: