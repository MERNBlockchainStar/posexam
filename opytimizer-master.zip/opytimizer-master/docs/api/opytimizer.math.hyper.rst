opytimizer.math.complex
========================

.. automodule:: opytimizer.math.complex
    :members:
    :private-members:
    :special-members: