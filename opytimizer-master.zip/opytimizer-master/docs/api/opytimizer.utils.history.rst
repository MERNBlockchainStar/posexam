opytimizer.utils.history
==========================

.. automodule:: opytimizer.utils.history
    :members:
    :private-members:
    :special-members: