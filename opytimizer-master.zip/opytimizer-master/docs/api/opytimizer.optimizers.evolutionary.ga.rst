opytimizer.optimizers.evolutionary.ga
======================================

.. automodule:: opytimizer.optimizers.evolutionary.ga
    :members:
    :private-members:
    :special-members: