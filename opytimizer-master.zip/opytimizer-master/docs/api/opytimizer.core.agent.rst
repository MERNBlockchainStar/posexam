opytimizer.core.agent
==========================

.. automodule:: opytimizer.core.agent
    :members:
    :private-members:
    :special-members: