opytimizer
===========

.. autoclass:: opytimizer.Opytimizer
   :members:
   :private-members:
   :special-members: