opytimizer.core.function
==========================

.. automodule:: opytimizer.core.function
    :members:
    :private-members:
    :special-members: