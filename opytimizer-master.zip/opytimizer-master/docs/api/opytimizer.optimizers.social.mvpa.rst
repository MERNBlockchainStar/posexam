opytimizer.optimizers.social.mvpa
==================================

.. automodule:: opytimizer.optimizers.social.mvpa
    :members:
    :private-members:
    :special-members: