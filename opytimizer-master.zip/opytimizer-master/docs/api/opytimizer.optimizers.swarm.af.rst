opytimizer.optimizers.swarm.af
===============================

.. automodule:: opytimizer.optimizers.swarm.af
    :members:
    :private-members:
    :special-members: