opytimizer.optimizers.swarm.sbo
================================

.. automodule:: opytimizer.optimizers.swarm.sbo
    :members:
    :private-members:
    :special-members: