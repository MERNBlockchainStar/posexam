opytimizer.core.node
==========================

.. automodule:: opytimizer.core.node
    :members:
    :private-members:
    :special-members: