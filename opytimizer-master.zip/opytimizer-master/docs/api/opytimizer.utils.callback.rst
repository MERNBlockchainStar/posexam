opytimizer.utils.callback
===========================

.. automodule:: opytimizer.utils.callback
    :members:
    :private-members:
    :special-members: