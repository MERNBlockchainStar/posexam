opytimizer.optimizers.evolutionary.foa
=======================================

.. automodule:: opytimizer.optimizers.evolutionary.foa
    :members:
    :private-members:
    :special-members: