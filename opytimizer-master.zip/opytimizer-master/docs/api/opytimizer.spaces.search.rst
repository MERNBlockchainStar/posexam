opytimizer.spaces.search
==========================

.. automodule:: opytimizer.spaces.search
    :members:
    :private-members:
    :special-members: