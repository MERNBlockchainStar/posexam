opytimizer.optimizers.swarm.fpa
================================

.. automodule:: opytimizer.optimizers.swarm.fpa
    :members:
    :private-members:
    :special-members: