opytimizer.optimizers.misc.gs
==============================

.. automodule:: opytimizer.optimizers.misc.gs
    :members:
    :private-members:
    :special-members: