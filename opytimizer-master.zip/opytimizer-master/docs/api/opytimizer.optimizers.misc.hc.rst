opytimizer.optimizers.misc.hc
==============================

.. automodule:: opytimizer.optimizers.misc.hc
    :members:
    :private-members:
    :special-members: