opytimizer.optimizers.boolean.bmrfo
====================================

.. automodule:: opytimizer.optimizers.boolean.bmrfo
    :members:
    :private-members:
    :special-members: