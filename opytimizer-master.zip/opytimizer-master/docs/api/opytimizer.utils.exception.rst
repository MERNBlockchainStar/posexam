opytimizer.utils.exception
==========================

.. automodule:: opytimizer.utils.exception
    :members:
    :private-members:
    :special-members: