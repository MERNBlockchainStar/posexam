opytimizer.optimizers.swarm.bwo
================================

.. automodule:: opytimizer.optimizers.swarm.bwo
    :members:
    :private-members:
    :special-members: