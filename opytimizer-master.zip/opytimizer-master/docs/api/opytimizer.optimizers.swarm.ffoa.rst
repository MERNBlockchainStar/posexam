opytimizer.optimizers.swarm.ffoa
=================================

.. automodule:: opytimizer.optimizers.swarm.ffoa
    :members:
    :private-members:
    :special-members: