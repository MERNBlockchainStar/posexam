opytimizer.optimizers.evolutionary.ep
======================================

.. automodule:: opytimizer.optimizers.evolutionary.ep
    :members:
    :private-members:
    :special-members: