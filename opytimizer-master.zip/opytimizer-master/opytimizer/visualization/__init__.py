"""Visualization package for all common opytimizer modules.
"""
