"""Opytimizer main library. Note that it consists
of several modules and sub-modules.
"""

from opytimizer.opytimizer import Opytimizer

__version__ = '3.0.3'
