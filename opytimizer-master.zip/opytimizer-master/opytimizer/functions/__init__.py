"""Functions package for all common opytimizer modules.
"""

from opytimizer.functions.constrained import ConstrainedFunction
from opytimizer.functions.weighted import WeightedFunction
