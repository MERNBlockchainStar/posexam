"""An optimizers package for all common opytimizer modules.
It contains specific packages of every optimization taxonomy
covered by opytimizer.
"""
