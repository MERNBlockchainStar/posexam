## Gravitation Voronoi

[http://cs.nyu.edu/courses/fall16/CSCI-GA.2965-001/voronoi_gravitational.html](http://cs.nyu.edu/courses/fall16/CSCI-GA.2965-001/voronoi_gravitational.html)

## Solution

We just stick to last position player made move at and place near him. In the end, we use minimax to prune and select best possible placement.
