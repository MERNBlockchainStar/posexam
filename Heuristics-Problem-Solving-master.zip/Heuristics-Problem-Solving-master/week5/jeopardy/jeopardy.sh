#!/bin/bash

python voronoi.py $1 $2 $3
