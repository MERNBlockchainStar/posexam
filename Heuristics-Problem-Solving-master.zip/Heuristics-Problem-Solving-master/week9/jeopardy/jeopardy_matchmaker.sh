#!/bin/bash
python main.py 1 $1
