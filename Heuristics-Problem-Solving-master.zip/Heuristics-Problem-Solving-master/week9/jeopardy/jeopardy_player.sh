#!/bin/bash
python main.py 0 $1
