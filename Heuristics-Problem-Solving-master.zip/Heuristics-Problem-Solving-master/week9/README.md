### Dating Game

[http://cs.nyu.edu/courses/fall16/CSCI-GA.2965-001/dating.html](http://cs.nyu.edu/courses/fall16/CSCI-GA.2965-001/dating.html)

## Solution

We use ridge regression to create a particular candidate from the available results and then use a clever heuristics of replacing the near zero qualities of the candidates with each other to check if we can get a better solution.
