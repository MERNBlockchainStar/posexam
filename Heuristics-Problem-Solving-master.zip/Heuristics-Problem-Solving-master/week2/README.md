## Optimal Touring

## Challenge

[http://cs.nyu.edu/courses/fall16/CSCI-GA.2965-001/tour.html](http://cs.nyu.edu/courses/fall16/CSCI-GA.2965-001/tour.html)

## Solution

We used clustering to create cluster which we will visit in particular orientations. They we applied shake and free method to get through the local maxima conditions
