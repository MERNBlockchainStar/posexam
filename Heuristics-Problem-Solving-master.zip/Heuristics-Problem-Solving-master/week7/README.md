## Dancing Without Stars

[http://cs.nyu.edu/courses/fall16/CSCI-GA.2965-001/dancing.html](http://cs.nyu.edu/courses/fall16/CSCI-GA.2965-001/dancing.html)

## Solution

We use hungarian algorithm to create the pairs and then we use breadth first search to create a path without any conflicts between the moving dancers. Edge cases to be taken care of.

This challenge had a lot of errors with other teams.
