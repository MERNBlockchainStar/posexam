#!/bin/bash

python main.py 1 $1 $2 $3 $4
