## Expanding nim

### Challenge

[http://cs.nyu.edu/courses/fall16/CSCI-GA.2965-001/expandingnim.html](http://cs.nyu.edu/courses/fall16/CSCI-GA.2965-001/expandingnim.html)

### Solution

We use dp based approach to generate all the possible moves of candidate and choose only the moves which don't put us in a losing state
