## Evasion

[http://cs.nyu.edu/courses/fall16/CSCI-GA.2965-001/evasion.html](http://cs.nyu.edu/courses/fall16/CSCI-GA.2965-001/evasion.html)

## Solution

Hunter: We try to put hunter in as smaller as possible box by creating and replacing walls accordingly. There are many edge cases to take care of.

Prey: We try to remain as close to hunter as possible. This is possibly the best startegy for prey as seen in redemption results.
