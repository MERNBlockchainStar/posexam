class Board:
    def __init__(self, xSize, ySize):
        self.grid = [[0 for i in range(0, xSize)] for j in range(0, ySize)]
        self.xSize = xSize
        self.ySize = ySize
