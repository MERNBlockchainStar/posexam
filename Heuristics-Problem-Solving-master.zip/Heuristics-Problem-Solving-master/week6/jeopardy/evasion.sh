#!/bin/bash

python game.py $1
