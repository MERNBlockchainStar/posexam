## No Tipping

## Challenge

[http://cs.nyu.edu/courses/fall16/CSCI-GA.2965-001/notipping.html](http://cs.nyu.edu/courses/fall16/CSCI-GA.2965-001/notipping.html)


## Solution

Alpha Beta pruning of moves of opponents and choosing the best move accordingly. Too much recursion was happening. IIRC, we used depth 5 tree.
